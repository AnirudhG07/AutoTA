For the linear differential equation \( \dot{x}=x \) and \( \dot{y}=y). Prove that the origin is source.
