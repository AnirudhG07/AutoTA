For the linear differential equation \( \dot{x}=y \) and \( \dot{y}=x). Prove that the origin is saddle.
