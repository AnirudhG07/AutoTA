Let \( f(x, y)=x^{3}-3 x+y^{2} \) for \( x, y \in \mathbb{R} \). Prove that at the points (1,0) and (-1,0) the gradient of \( f \) is zero.
