Let \( f: \mathbb{R}^{2} \rightarrow \mathbb{R} \) be the function given by
\[
f(x, y)=\left\{\begin{array}{ll}
x, & \text { if } y=x^{3} \\
0, & \text { if } y \neq x^{3}
\end{array}\right.
\]

Prove that the function \( f \) is continuous at \( (0,0) \).
