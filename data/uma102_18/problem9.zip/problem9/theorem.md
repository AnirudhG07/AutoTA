For the linear differential equation \( \dot{x}=y \) and \( \dot{y}=-x-y). Prove that the origin is circulation.
