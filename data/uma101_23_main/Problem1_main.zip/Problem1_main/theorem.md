Let \( A, B \subset \mathbb{R} \) be nonempty sets that are bounded above. Then prove that \( A \cup B \) is nonempty and bounded above, and
\[
\sup (A \cup B)=\max \{\sup A, \sup B\}
\]
