Let \( f:(-1,1) \rightarrow \mathbb{R} \) be such that
\[
\lim \_{h \rightarrow 0}|f(h)-f(-h)|=0
\]

Then prove that \( \lim \_{h \rightarrow 0} f(h) \) does not exist.
