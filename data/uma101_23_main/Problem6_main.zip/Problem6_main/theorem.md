Prove that the series \( \sum\_{n=1}^{\infty}\left(\sin \frac{1}{n}\right)^{3 / 2} \) is convergent.
