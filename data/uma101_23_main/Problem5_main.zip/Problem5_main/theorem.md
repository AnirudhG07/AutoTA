Give a proof by first principles of:
the function \( f(x)=x^{1 / 3} \) is continuous at \( x=1 \).
Note. You must give a direct \( \epsilon-\delta \) proof. You cannot quote any theorems such as the inverse function theorem, the mean value theorem, etc.
